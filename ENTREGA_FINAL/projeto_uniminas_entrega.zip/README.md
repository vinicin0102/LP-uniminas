# Uniminas EAD - Landing Page

Este pacote contém o código-fonte completo e as configurações para execução da Landing Page com Chatbot de IA integrado.

## Arquivos Inclusos:
- index.html e style.css: Frontend da aplicação (Interface, animações e formulário).
- api/chat.js: Backend Serverless (Vercel) responsável por comunicar com a OpenAI (ChatGPT) com segurança.
- package.json: Dependências do backend (SDK da OpenAI).
- database_schema.sql: Script para criação do banco de dados no Supabase.
- .env.example: Exemplo de configuração de variáveis de ambiente.

## Como Executar Localmente
1. Abra o arquivo index.html em qualquer navegador moderno.
2. (Opcional) Para rodar um servidor local: python -m http.server 3000
3. Nota: O Chatbot requer que o backend /api/chat esteja rodando (via Vercel CLI 'vercel dev' ou hospedado no Vercel).

## Configurações de Segurança
- As chaves de API foram removidas do arquivo index.html por segurança.
- Para conectar ao banco, adicione sua URL e Chave ANON do Supabase nas variáveis supabaseUrl e supabaseKey dentro da função submitForm no index.html.
- Para o Chatbot, adicione a variável OPENAI_API_KEY nas configurações de Environment do Vercel.